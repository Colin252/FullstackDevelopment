package net.purocodigo.encuestabackend.models.responses;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CreatedPollReplyRest {
    
    private long id;

}
