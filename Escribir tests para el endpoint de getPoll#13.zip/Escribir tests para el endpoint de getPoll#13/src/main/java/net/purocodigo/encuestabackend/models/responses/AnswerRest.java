package net.purocodigo.encuestabackend.models.responses;

import lombok.Data;

@Data
public class AnswerRest {
    private long id;

    private String content;
}
