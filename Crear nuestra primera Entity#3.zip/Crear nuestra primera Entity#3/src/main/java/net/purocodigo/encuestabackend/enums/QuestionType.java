package net.purocodigo.encuestabackend.enums;

public enum QuestionType {
    RADIO, SELECT, CHECKBOX
}
